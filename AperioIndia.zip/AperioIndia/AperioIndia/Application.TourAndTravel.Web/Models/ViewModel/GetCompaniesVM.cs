﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.TourAndTravel.Web.Models
{
    public class GetCompaniesVM
    {
        public string TravellerName { get; set; }
        public string TravellerEmail { get; set; }
    }
}