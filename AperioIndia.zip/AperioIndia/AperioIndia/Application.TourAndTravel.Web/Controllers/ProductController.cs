﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.TourAndTravel.Web.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult glass_film()
        {
            return View();
        }
        public ActionResult film_roll()
        {
            return View();
        }
        public ActionResult vinyl_film()
        {
            return View();
        }

        public ActionResult vinyl_film_roll()
        {
            return View();
        }
        public ActionResult glossy_printable_paper_rolls()
        {
            return View();
        }
        public ActionResult tape()
        {
            return View();
        }

        public ActionResult translight()
        {
            return View();
        }
        public ActionResult printed_wallpaper()
        {
            return View();
        }
        public ActionResult flex_roll()
        {
            return View();
        }
        public ActionResult cold_lamination_film_roll()
        {
            return View();
        }
        public ActionResult pvc_banner_media_roll()
        {
            return View();
        }
        public ActionResult paper_roll()
        {
            return View();
        }
        public ActionResult pvc_banner_media()
        {
            return View();
        }
        public ActionResult frontlit_fabric_roll()
        {
            return View();
        }

    }
}